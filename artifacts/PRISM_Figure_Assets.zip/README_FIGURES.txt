PRISM figure redesign, 12 October 2026
Eight main figures: editable PDF/SVG, PNG previews, source CSV, saved result inputs and Matplotlib code.
Install requirements_FIGURES.txt, then from this extracted root run python scripts/make_journal_figures.py.
The plotting code uses only the included saved evidence and performs no fitting or new statistical tests.
Illustrative event slots in the protocol schematic are labelled and are not empirical timestamps.
The default figure width is 7.2 inches, with editable TrueType text; manuscript embedding scales uniformly.
