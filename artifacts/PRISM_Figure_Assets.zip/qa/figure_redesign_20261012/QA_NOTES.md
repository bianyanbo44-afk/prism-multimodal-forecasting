# Figure rendering notes

The eight current main figures use Matplotlib exclusively, with the shared editable TrueType PDF/SVG settings and a 7.2-inch artwork width. The manuscript embeds each at its text width. Font-size verification applies to the actual PDFs; the source helper uses at least 8-point plot text. Illustrative event slots in the protocol diagram are labelled and do not serve as empirical observations.

Each plotting module is preflighted together with its actual shared style/export implementation because a single-file static parser cannot follow imports. No source preflight failures remain. Static warnings are reviewed as follows:

- PNG files are 350-dpi previews; PDF/SVG are the authoritative vector artwork. No TIFF is needed for these vector diagrams and charts.
- The validator cannot infer a width referenced through the shared WIDTH constant. Exported provenance and PDF page dimensions record the measured 7.2-inch width.
- The validation-transfer figure shows saved split-specific means. No inferential interval was saved for those descriptive ratios, and the plot does not invent one. The map distributions use all saved intervention draws and empirical quantiles rather than sampling confidence intervals.

Automatic panel alignment uses the exported axes rectangles with 1.5-point physical tolerance. PDF font and collision scans accompany the final exported files. The rendered manuscript is inspected in addition to the individual artwork.

All plot populations are retained for the stated comparisons: fifteen construct/control cells, eight calibration cells, thirty historical control cells, nine plants, all independent aligned/numerical/timing transfer configurations and one hundred forty map effects. Coverage and scaling each retain all five datasets. Figure source CSVs document direct arithmetic transformations and source identifiers. No model fitting, new statistical tests, forecast changes, donor changes or empirical data editing occur in this redesign.
