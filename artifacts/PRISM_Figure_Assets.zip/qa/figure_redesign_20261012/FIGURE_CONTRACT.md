# Figure redesign contract

Eight main figures, using the established Python/Matplotlib workflow and saved observations. Export editable PDF/SVG and 350-dpi PNG previews; retain source CSVs, input hashes and alignment records. The manuscript uses the same scientific claims and result populations.

| Figure | Question | Evidence architecture |
|---|---|---|
| Protocol | What is changed in an irregular multimodal forecast, and which evaluation object is measured? | Illustrative event-slot schematic, preserved fields, fixed/refitted comparison |
| Construct controls | Which stipulated content cue drives the loss response? | Direction/source edit example, two complementary target responses, timing boundary; all 15 controls retained |
| Photovoltaic comparison | How do fixed-model response and condition-retrained value differ? | Aggregate losses and gains, paired plant effects; all nine plants retained |
| Signal calibration | Does the evaluation respond to known signal, and what occurs under null signal? | Effect/uncertainty and detection/uncertainty across all eight cells |
| Historical checkpoints | How does reassignment differ from zero-vector sensitivity? | Point effects and saved block-two intervals for all 15 cells per control |
| Validation transfer | Does saved validation improvement persist on the later test period? | Matched split losses relative to persistence, all independent aligned/numerical/timing configurations |
| Intervention maps | Is the direction of a fixed-model effect stable across the evaluated maps? | All 140 map effects, separately showing irregular encoders and the shared photovoltaic context |
| Evaluation boundaries | What is achieved by the intervention, and how does scaling affect a reported score? | Changed-position coverage and paired scaling contrast on all five datasets |

Illustrative protocol events are labelled as a schematic and carry no experimental timestamps or performance values. No new fitting, new inferential tests, post-hoc qualification or favorable subset selection. Empirical ranges over intervention maps remain distinct from sampling confidence intervals. The validation/test ratio is a descriptive display transformation of saved positive MSEs, with split-specific persistence denominators. Historical effect and uncertainty denominators must match.

Use 1.5-pt panel-alignment tolerance, source preflight, PDF text audit and rendered collision audit. Resolve failures and inspect the actual exported panels and integrated manuscript at its printed size. Preserve the prior manuscript/figures in the local snapshot.
