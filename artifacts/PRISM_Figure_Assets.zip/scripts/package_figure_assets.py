"""Package the current editable figure artwork, inputs, code and review records."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "delivery"


def main():
    state = json.loads((ROOT / "manuscript/figures/figure_source_manifest.json").read_text(encoding="utf-8"))
    paths = {"manuscript/figures/figure_source_manifest.json", "scripts/package_figure_assets.py"}
    paths.update(row["path"] for row in state["scripts"])
    paths.update(row["path"] for row in state["source_files"])
    for name in state["main_figures"]:
        paths.update(f"manuscript/figures/{name}.{extension}"
                     for extension in ["pdf", "svg", "png", "alignment.json", "provenance.json", "collisions.json", "text-audit.json"])
        csv_path = f"manuscript/figures/{name}_source.csv"
        if (ROOT / csv_path).is_file():
            paths.add(csv_path)
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / "qa/figure_redesign_20261012").glob("*.md"))
    paths.add("qa/figure_redesign_20261012/FIGURE_QA.json")
    paths.add("qa/figure_redesign_20261012/FIGURE_OVERVIEW.png")
    entries = []
    archive = OUT / "PRISM_Figure_Assets.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for relative in sorted(paths):
            path = ROOT / relative
            data = path.read_bytes()
            z.writestr(relative, data)
            entries.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        requirements = "\n".join(f"{name}=={importlib.metadata.version(name)}" for name in ["numpy", "matplotlib"]) + "\n"
        z.writestr("requirements_FIGURES.txt", requirements)
        z.writestr("README_FIGURES.txt",
                   "PRISM figure redesign, 12 October 2026\n"
                   "Eight main figures: editable PDF/SVG, PNG previews, source CSV, saved result inputs and Matplotlib code.\n"
                   "Install requirements_FIGURES.txt, then from this extracted root run python scripts/make_journal_figures.py.\n"
                   "The plotting code uses only the included saved evidence and performs no fitting or new statistical tests.\n"
                   "Illustrative event slots in the protocol schematic are labelled and are not empirical timestamps.\n"
                   "The default figure width is 7.2 inches, with editable TrueType text; manuscript embedding scales uniformly.\n")
        z.writestr("FIGURE_ASSETS_MANIFEST.json", json.dumps(entries, indent=2) + "\n")
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for row in entries:
            assert hashlib.sha256(z.read(row["path"])).hexdigest() == row["sha256"]
    print(f"Packaged eight figure assets: {len(entries)} source/artwork/QA files")


if __name__ == "__main__":
    main()
