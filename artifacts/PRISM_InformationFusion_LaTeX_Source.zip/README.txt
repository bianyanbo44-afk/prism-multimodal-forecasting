PRISM Information Fusion journal extension
Editorially polished manuscript, 13 October 2026. Public research artifact; no journal-submission claim.
Repository: https://github.com/bianyanbo44-afk/prism-multimodal-forecasting
Compile with pdflatex main.tex, bibtex main, then pdflatex main.tex twice.
Requires elsarticle, lmodern, microtype, booktabs, amsmath, amssymb, longtable, enumitem, geometry, hyperref, xurl and placeins.
The package includes editable text, bibliography, original figure PDFs and source identities.
Raw benchmark data, pretrained model weights and third-party paper PDFs are excluded.
Original numerical evidence and full executable scripts are retained in the surrounding journal_extension_20261012 project.
